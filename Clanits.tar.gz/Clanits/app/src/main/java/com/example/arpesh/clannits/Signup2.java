package com.example.arpesh.clannits;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;


public class Signup2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_signup2);

    }

}
